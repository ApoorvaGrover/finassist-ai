# FinAssist AI — Streamlit Community Cloud project

A deployable educational prototype for financial literacy and preliminary government-scheme discovery.

## Included files
- `streamlit_app.py` — main Streamlit application
- `requirements.txt` — pinned Python dependency
- `.streamlit/config.toml` — theme and server configuration
- `.gitignore` — excludes local environments and secrets

## Deploy online with Streamlit Community Cloud

1. Download and extract this ZIP file.
2. Sign in to GitHub and create a new repository, for example `finassist-ai`.
3. Upload the **contents** of this folder to the repository root. Keep `.streamlit/config.toml` inside the `.streamlit` folder.
4. Visit https://share.streamlit.io/ and sign in using GitHub.
5. Select **Create app**.
6. Choose your repository, branch (usually `main`) and main file path `streamlit_app.py`.
7. In Advanced settings, choose Python 3.12 if a Python version selector is shown.
8. Select **Deploy**. When the build completes, Streamlit provides a shareable `*.streamlit.app` URL.

Official instructions: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app

## Run locally (optional)

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Demo walkthrough
1. Open **My Profile** and enter fictional sample details.
2. Save the profile.
3. Open **Find Schemes** to see preliminary rule-based matches.
4. Ask the assistant about savings, loans, insurance, pensions or UPI fraud.
5. Switch between English and Hindi.
6. Explore Financial Learning, My Roadmap and Fraud Safety.

## Scope and limitations
- Educational student prototype only; not an official government service.
- The assistant uses built-in topic matching, not a generative AI model.
- Scheme matching is simplified and is not an official eligibility decision. Confirm current terms, exclusions and documents with the relevant government department.
- Voice recording is available as a UI demonstration; speech-to-text is not enabled in this cloud-ready baseline.
- Profile data is held in the active Streamlit session, not in a permanent database or user account.
- Use fictional details only. Never enter Aadhaar numbers, bank account numbers, OTPs, passwords or other sensitive information.
- The app does not submit applications, make payments, provide loans, sell insurance or recommend investments.
